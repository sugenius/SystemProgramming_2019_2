#include<stdio.h>
int main(){
	printf("Hello C world\m");
	return 0;
}


